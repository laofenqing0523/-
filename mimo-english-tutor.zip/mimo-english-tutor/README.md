# Mimo English Tutor 🎯

基于小米Mimo大模型的智能英语口语陪练Agent，支持多场景对话练习、实时纠错和发音建议。

## 项目背景

在英语学习过程中，很多人面临"开口难"的问题——缺乏真实的对话场景和即时的反馈。本项目利用小米Mimo大模型的能力，构建了一个智能英语口语陪练系统，让学习者可以随时进行口语练习并获得专业指导。

## 核心功能

- **多场景对话练习**：日常交流、商务英语、旅游场景、雅思口语等
- **实时语法纠错**：智能识别语法错误并给出改进建议
- **词汇升级建议**：将简单表达升级为更地道的英语
- **发音指导**：针对易错发音给出提示
- **学习报告生成**：总结对话中的亮点和待提升点

## 项目架构

```
mimo-english-tutor/
├── src/
│   ├── agent.py          # Agent核心逻辑
│   ├── mimo_client.py    # Mimo API客户端
│   ├── prompts.py        # 场景提示词模板
│   └── main.py           # 程序入口
├── examples/
│   └── basic_chat.py     # 基础对话示例
├── docs/
│   └── ARCHITECTURE.md   # 架构设计文档
├── config.example.yaml   # 配置文件模板
└── requirements.txt      # 依赖列表
```

## 快速开始

### 1. 安装依赖

```bash
git clone https://github.com/your-username/mimo-english-tutor.git
cd mimo-english-tutor
pip install -r requirements.txt
```

### 2. 配置API密钥

```bash
cp config.example.yaml config.yaml
# 编辑config.yaml，填入你的Mimo API密钥
```

### 3. 运行示例

```bash
python src/main.py
```

或使用交互模式：

```bash
python examples/basic_chat.py
```

## 使用示例

```python
from src.agent import EnglishTutorAgent

# 创建陪练Agent
agent = EnglishTutorAgent(scenario="daily")

# 开始对话
response = agent.chat("Hello, I want to practice English.")
print(response)
```

## 技术特点

1. **场景化提示词设计**：针对不同学习场景定制提示词，让对话更贴近实际应用
2. **多轮对话记忆**：支持上下文理解，保持对话连贯性
3. **流式输出支持**：实时返回模型响应，提升交互体验
4. **错误追踪机制**：记录用户常见错误，便于针对性提升

## 依赖说明

- Python 3.8+
- 小米Mimo API访问权限

## 项目路线图

- [x] 基础对话框架
- [x] 多场景支持
- [ ] 语音识别集成
- [ ] 学习数据分析面板
- [ ] Web界面

## 致谢

感谢小米Mimo大模型提供的API支持，让这个项目成为可能。

## License

MIT License

---

如果你觉得这个项目有帮助，欢迎⭐Star支持！