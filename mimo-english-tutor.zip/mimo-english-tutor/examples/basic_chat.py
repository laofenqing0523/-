"""
基础对话示例
演示如何使用Mimo English Tutor进行简单对话
"""

import os
import sys
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.agent import EnglishTutorAgent


def main():
    """基础对话示例"""

    # 方式1：直接使用API密钥创建
    # api_key = "your-api-key-here"
    # agent = EnglishTutorAgent(api_key=api_key, scenario="daily")

    # 方式2：从环境变量读取
    api_key = os.getenv("MIMO_API_KEY")
    if not api_key:
        print("请设置环境变量 MIMO_API_KEY 或在代码中直接填写API密钥")
        return

    # 创建日常对话场景的Agent
    agent = EnglishTutorAgent(
        api_key=api_key,
        scenario="daily",
        temperature=0.7
    )

    print(f"Agent: {agent}")
    print(f"场景信息: {agent.get_scenario_info()}")
    print("-" * 50)

    # 开始对话
    print("Tutor:", agent.get_opening_line())
    print()

    # 模拟几轮对话
    conversations = [
        "Hi! I want to practice my English.",
        "I'm doing well, thanks! What should we talk about?",
        "That sounds good. I like playing basketball in my free time."
    ]

    for user_input in conversations:
        print(f"You: {user_input}")
        response = agent.chat(user_input)
        print(f"Tutor: {response}")
        print()

    print(f"对话历史: {len(agent.get_history())} 条消息")


if __name__ == "__main__":
    main()