"""
Mimo English Tutor 主程序
交互式英语口语陪练
"""

import os
import sys
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.markdown import Markdown
import yaml

from src.agent import EnglishTutorAgent, create_agent_from_config
from src.prompts import SCENARIO_CONFIG, ScenarioType


console = Console()


def print_welcome():
    """打印欢迎信息"""
    console.clear()
    console.print(Panel.fit(
        "[bold blue]Mimo English Tutor[/bold blue]\n"
        "基于小米Mimo大模型的智能英语口语陪练",
        title="Welcome!",
        border_style="blue"
    ))
    console.print()


def select_scenario() -> ScenarioType:
    """选择对话场景"""
    console.print("[bold]请选择对话场景:[/bold]")
    for i, (key, info) in enumerate(SCENARIO_CONFIG.items(), 1):
        console.print(f"  {i}. [cyan]{info['name']}[/cyan] - {info['description']}")
    console.print()

    choice = Prompt.ask(
        "选择场景",
        choices=["1", "2", "3", "4"],
        default="1"
    )

    scenarios = list(SCENARIO_CONFIG.keys())
    return scenarios[int(choice) - 1]


def load_config() -> dict | None:
    """加载配置文件"""
    config_path = Path(__file__).parent.parent / "config.yaml"
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    return None


def get_api_key() -> str:
    """获取API密钥"""
    # 先从环境变量
    api_key = os.getenv("MIMO_API_KEY")
    if api_key:
        return api_key

    # 再从配置文件
    config = load_config()
    if config and config.get("api", {}).get("api_key"):
        return config["api"]["api_key"]

    # 最后交互输入
    console.print("[yellow]未找到API密钥，请输入:[/yellow]")
    return Prompt.ask("Mimo API Key", password=True)


def interactive_chat(agent: EnglishTutorAgent):
    """交互式对话"""
    info = agent.get_scenario_info()
    console.print(f"\n[bold green]当前场景: {info['name']}[/bold green]")
    console.print(f"[dim]难度: {info['difficulty']} | 输入 'quit' 退出, 'reset' 重置对话[/dim]\n")

    # 显示开场白
    opening = agent.get_opening_line()
    console.print(f"[bold blue]Tutor:[/bold blue] {opening}\n")

    while True:
        try:
            user_input = Prompt.ask("[bold green]You[/bold green]")

            if user_input.lower() in ["quit", "exit", "q"]:
                console.print("\n[yellow]感谢使用 Mimo English Tutor! 再见![/yellow]")
                break

            if user_input.lower() == "reset":
                agent.reset()
                console.print("[dim]对话已重置[/dim]")
                opening = agent.get_opening_line()
                console.print(f"\n[bold blue]Tutor:[/bold blue] {opening}\n")
                continue

            if not user_input.strip():
                continue

            # 获取回复
            with console.status("[bold blue]思考中...[/bold blue]"):
                response = agent.chat(user_input)

            console.print(f"\n[bold blue]Tutor:[/bold blue]")
            console.print(Markdown(response))
            console.print()

        except KeyboardInterrupt:
            console.print("\n[yellow]已退出[/yellow]")
            break
        except Exception as e:
            console.print(f"[red]错误: {e}[/red]")


def main():
    """主函数"""
    print_welcome()

    # 获取API密钥
    api_key = get_api_key()
    if not api_key:
        console.print("[red]请设置MIMO_API_KEY环境变量或在config.yaml中配置api_key[/red]")
        sys.exit(1)

    # 选择场景
    scenario = select_scenario()

    # 创建Agent
    try:
        agent = EnglishTutorAgent(
            api_key=api_key,
            scenario=scenario
        )
        console.print(f"[green]Agent创建成功: {agent}[/green]\n")
    except Exception as e:
        console.print(f"[red]Agent创建失败: {e}[/red]")
        sys.exit(1)

    # 开始对话
    interactive_chat(agent)


if __name__ == "__main__":
    main()