"""
英语陪练Agent核心逻辑
整合Mimo客户端和场景化提示词，实现多轮对话
"""

import yaml
from typing import Optional
from pathlib import Path

from .mimo_client import MimoClient
from .prompts import get_system_prompt, get_scenario_info, OPENING_LINES, ScenarioType


class EnglishTutorAgent:
    """英语口语陪练Agent"""

    def __init__(
        self,
        api_key: str,
        scenario: ScenarioType = "daily",
        base_url: str = "https://api.xiaomi.com/mimo/v1",
        model: str = "mimo-7b",
        max_history: int = 10,
        temperature: float = 0.7
    ):
        """
        初始化Agent

        Args:
            api_key: Mimo API密钥
            scenario: 对话场景
            base_url: API基础URL
            model: 模型名称
            max_history: 最大对话历史轮数
            temperature: 生成温度
        """
        self.client = MimoClient(api_key, base_url, model)
        self.scenario = scenario
        self.max_history = max_history
        self.temperature = temperature

        # 对话历史
        self.messages: list[dict] = []

        # 设置系统提示词
        self._init_system_prompt()

    def _init_system_prompt(self):
        """初始化系统提示词"""
        system_prompt = get_system_prompt(self.scenario)
        self.messages = [{"role": "system", "content": system_prompt}]

    def chat(self, user_input: str) -> str:
        """
        进行一轮对话

        Args:
            user_input: 用户输入

        Returns:
            Agent回复
        """
        # 添加用户消息
        self.messages.append({"role": "user", "content": user_input})

        # 获取回复
        response = self.client.chat(
            messages=self.messages,
            temperature=self.temperature
        )

        # 添加助手消息到历史
        self.messages.append({"role": "assistant", "content": response})

        # 控制历史长度
        self._trim_history()

        return response

    def chat_stream(self, user_input: str):
        """
        流式对话

        Args:
            user_input: 用户输入

        Yields:
            响应片段
        """
        self.messages.append({"role": "user", "content": user_input})

        full_response = ""
        for chunk in self.client.chat(
            messages=self.messages,
            temperature=self.temperature,
            stream=True
        ):
            full_response += chunk
            yield chunk

        self.messages.append({"role": "assistant", "content": full_response})
        self._trim_history()

    def _trim_history(self):
        """控制对话历史长度"""
        # 保留system prompt + max_history轮对话
        if len(self.messages) > self.max_history * 2 + 1:
            # 保留第一条system消息
            system_msg = self.messages[0]
            self.messages = [system_msg] + self.messages[-(self.max_history * 2):]

    def reset(self, scenario: Optional[ScenarioType] = None):
        """
        重置对话

        Args:
            scenario: 可选，切换到新场景
        """
        if scenario:
            self.scenario = scenario
        self._init_system_prompt()

    def get_opening_line(self) -> str:
        """获取开场白"""
        import random
        return random.choice(OPENING_LINES.get(self.scenario, OPENING_LINES["daily"]))

    def get_scenario_info(self) -> dict:
        """获取当前场景信息"""
        return get_scenario_info(self.scenario)

    def get_history(self) -> list[dict]:
        """获取对话历史"""
        return self.messages[1:]  # 排除system prompt

    def __repr__(self) -> str:
        info = self.get_scenario_info()
        return f"EnglishTutorAgent(scenario={info['name']}, history={len(self.get_history())} turns)"


def create_agent_from_config(config_path: str | Path) -> EnglishTutorAgent:
    """
    从配置文件创建Agent

    Args:
        config_path: 配置文件路径

    Returns:
        配置好的Agent实例
    """
    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    return EnglishTutorAgent(
        api_key=config["api"]["api_key"],
        scenario=config["agent"].get("scenario", "daily"),
        base_url=config["api"].get("base_url", "https://api.xiaomi.com/mimo/v1"),
        model=config["api"].get("model", "mimo-7b"),
        max_history=config["agent"].get("max_history", 10),
        temperature=config["agent"].get("temperature", 0.7)
    )


if __name__ == "__main__":
    # 简单测试
    print("EnglishTutorAgent 模块加载成功")
    print(f"可用场景: daily, business, travel, ielts")