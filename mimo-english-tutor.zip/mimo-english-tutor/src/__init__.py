"""
Mimo English Tutor - 基于小米Mimo大模型的英语口语陪练Agent
"""

__version__ = "0.1.0"
__author__ = "Your Name"