"""
Mimo API 客户端封装
提供与小米Mimo大模型的交互接口
"""

import requests
from typing import Optional, Generator, Dict, Any


class MimoClient:
    """小米Mimo API客户端"""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.xiaomi.com/mimo/v1",
        model: str = "mimo-7b"
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

    def chat(
        self,
        messages: list[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stream: bool = False
    ) -> str | Generator[str, None, None]:
        """
        发送对话请求

        Args:
            messages: 对话消息列表，格式 [{"role": "user", "content": "..."}]
            temperature: 生成温度
            max_tokens: 最大token数
            stream: 是否流式输出

        Returns:
            模型响应文本或生成器
        """
        url = f"{self.base_url}/chat/completions"
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream
        }

        if stream:
            return self._stream_chat(url, payload)
        else:
            return self._sync_chat(url, payload)

    def _sync_chat(self, url: str, payload: dict) -> str:
        """同步请求"""
        response = requests.post(
            url,
            headers=self.headers,
            json=payload,
            timeout=60
        )
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]

    def _stream_chat(self, url: str, payload: dict) -> Generator[str, None, None]:
        """流式请求"""
        response = requests.post(
            url,
            headers=self.headers,
            json=payload,
            stream=True,
            timeout=60
        )
        response.raise_for_status()

        for line in response.iter_lines():
            if line:
                line = line.decode("utf-8")
                if line.startswith("data: "):
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    import json
                    chunk = json.loads(data)
                    if chunk["choices"][0].get("delta", {}).get("content"):
                        yield chunk["choices"][0]["delta"]["content"]

    def __repr__(self) -> str:
        return f"MimoClient(model={self.model})"


# 使用示例
if __name__ == "__main__":
    # 请替换为你的实际API密钥
    client = MimoClient(api_key="your-api-key")

    messages = [
        {"role": "system", "content": "你是一个友好的英语老师。"},
        {"role": "user", "content": "Hello, how are you?"}
    ]

    response = client.chat(messages)
    print(response)